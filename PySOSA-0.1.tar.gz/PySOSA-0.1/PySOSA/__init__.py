from rdflib import Graph, URIRef, BNode, Literal, Namespace, RDF, RDFS
from PySOSA.landrs_module import Platform, Sensor, Observation
from PySOSA.landrs_module import FeatureOfInterest, ObservableProperty
from PySOSA.landrs_module import Actuator, Procedure, Actuation, Stimulus, ActuableProperty
from pyobs_pyobs import obsgraph, sosa, Sensor, ssnext