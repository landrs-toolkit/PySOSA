# Dummy Contributing: Hack2 Miniprojects proposals and wrapup disscussion:

1.  1st pass implement PySOSA complete to point of Read in CO2.csv and ArdupilotFlightLog.csv and spit out HDT and text tripples

2.  PySOSA - OpenAPI spec.  Demo with with Flask-DB&Leaflet //use PyGEOAPI

3.//  UXS Model Reuse of VSSO(?) or custom

4.//  UXS Dataset Modeling //Copy from [SELFIE](https://github.com/opengeospatial/SELFIE)

5. Drone Data Buddy Prequel:
    Webform based Pilot and Metadata collection
    Use javascript
    Containerized
    Phone renderable and persistent store tripplestore
    https://www.rubensworks.net/blog/2019/10/06/using-rdf-in-javascript/
    
6. Drone Data Buddy:
    Phone App
    Server App
    Snap/Pi deployable App
    Wishlist: DroneDataPub Container
    
7. QGIS demo:
    - Ingest Trajectory
    - Prov annotation of analysis
    (use Wfs3 endpoint plugin, requires our dev of tripplestore update from QGIS funcs)

8. NEEMA_LD library
    
# WG Tasks
- Drone Data Product Levels
- Assessment of MIF FAIR Data Metrics and publication for formal comment period
- Enagement with FAIR Data Matrix WG
- Collection of drone data

# Other TODOs
JW: 
- Cleanup repo and document this week's work including relevant links
- Engage with I-ADOPT
- QDIT

Chuck:
- Formalise MIF (Find ontologies and holes)


