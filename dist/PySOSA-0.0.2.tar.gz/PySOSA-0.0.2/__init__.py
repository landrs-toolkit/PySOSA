from rdflib import Graph, URIRef, BNode, Literal, Namespace, RDF, RDFS
from PySOSA import Platform, Sensor, Observation
